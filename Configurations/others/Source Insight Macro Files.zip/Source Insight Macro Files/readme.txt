Source Insight Macro Files(https://www.sourceinsight.com/download/macro-files/)
autoexp.em              Automatically expands C statements like if, for, while, switch, etc..  
closebuf.em             Close all non-dirty file windows  
CloseOldWindows.em      Closes all but the most recently visited windows and files. Any dirty files are kept open.  
comment.em              Comment/Uncomment the selected block of text using single line comments and indent it  
CompleteWord.em         Word completion within a buffer  
eventsample.em          contains example event functions  
home.em                 Extends the selection back to the first non-white space on the current line.   
matchdelim.em           Finds matching scoping delimiters and jumps to them  
multikey.em             Can be used to create a secondary key mapping which maps keys after an initial	key press.  
PrintSelection.em       Prints the currently selected text.   
ProgressiveSearch.em    command that performs a progressive search as the user types.  
replace.em              Replace a list of strings across the whole project.  
ReplaceSpans.em         Replaces patterns that span lines  
siutils.em              Misc utilities  
spacetotab.em           Converts leading spaces to tabs in C or C++ source lines  
stringutils.em          Assorted string utility functions used by some other macro files.  
Tabby.em                Converts spaces to tabs and tabs to spaces.  
TrimSpaces.em           This function trims white spaces from the ends of the selected lines.  
utils.em                Misc utilities.  
wordstar.em             Wordstar Keyboard Emulation

==================================================================================================================
To add a macro file:

Add the macro file to your project by selecting Project > Add and Remove Project Files. If you add the macro file to the Base project instead, it will be available in all projects.
Select Options->Key Assignments.
Find and select the macro command name in the command list. You can start to type its name to find it quickly in the list.
Click Assign New Key to bind a key to the macro.
Press the key combination you prefer, then click OK.
Now you can run the macro command using the key combination.
Alternatively, you can put the macro command on a menu by selecting Options > Menu Assignments.